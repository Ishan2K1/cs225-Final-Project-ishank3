#!/bin/bash

# Setup shell script that will help "Bake" the project for ease of use

cmake3 -Wno-dev .
make