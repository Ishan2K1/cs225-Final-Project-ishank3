#define CATCH_CONFIG_MAIN
#include "catch2/catch.hpp"

// https://github.com/catchorg/Catch2/blob/devel/docs/own-main.md#top